package com.example.shiv.measurementconversionapp;

import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

public class MainActivity extends AppCompatActivity
implements OnEditorActionListener {

    private EditText InputText;
    private TextView FromLabel;
    private TextView ToLabel;
    private TextView DisplayLabel;
    private Spinner Conversions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        InputText = (EditText)findViewById(R.id.editText);
        FromLabel = (TextView) findViewById(R.id.FromTextView);
        ToLabel = (TextView) findViewById(R.id.ToTextView);
        DisplayLabel = (TextView) findViewById(R.id.DisplayTextView);
        Conversions = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.Conversions, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        Conversions.setAdapter(adapter);
        Conversions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int position, long arg3) {
                // TODO Auto-generated method stub
                Object item = arg0.getItemAtPosition(position).toString();

                if(position ==0)
                {
                    FromLabel.setText("Miles");
                    ToLabel.setText("Kilometers");
                }
                else if(position ==1)
                {
                    FromLabel.setText("Kilometers");
                    ToLabel.setText("Miles");
                }
                else if(position ==2)
                {
                    FromLabel.setText("Inches");
                    ToLabel.setText("Centimeter");
                }
                else
                {
                    FromLabel.setText("Centimeter");
                    ToLabel.setText("Inches");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        InputText.setOnEditorActionListener(this);
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

        if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
            ComputeConversion();
        }
        return false;
    }
    /*
    Miles to Kilometers:     1.6093
    Kilometers to Miles:     0.6214
    Inches to Centimeters:   2.54
    Centimeters to Inches:   0.3937

     */

    private void ComputeConversion() {

        float Temp=0;
        float current = Float.parseFloat(InputText.getText().toString());
        int position =Conversions.getSelectedItemPosition();
        switch(position)
        {
            case 0:
                Temp = (float) (current * 1.6093);
                DisplayLabel.setText(Temp + "");
                break;
            case 1:
                Temp = (float) (current * 0.6214);
                DisplayLabel.setText(Temp + "");
                break;
            case 2:
                Temp = (float) (current * 2.54);
                DisplayLabel.setText(Temp + "");
                break;
            case 3:
                Temp = (float) (current * 0.3937);
                DisplayLabel.setText(Temp + "");
                break;
        }

    }

}
